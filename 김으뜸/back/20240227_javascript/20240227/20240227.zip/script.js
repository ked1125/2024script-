console.log('외부파일입니다.');
// dev option창(크롬의 검사창) - console탭에서 출력된다. 

alert('외부파일')